tinyMCE_GZ.init({
	// plugins must be the same as in tinyMCE.init
	plugins : "paste,safari",
	themes : "advanced",
	languages : "en",
	disk_cache : true,
	debug : false
});