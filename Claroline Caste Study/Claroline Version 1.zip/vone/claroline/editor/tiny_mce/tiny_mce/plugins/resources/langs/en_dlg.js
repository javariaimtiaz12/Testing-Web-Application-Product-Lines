tinyMCE.addI18n('en.resources_dlg',{
	title : "Resources linker",
	labelTitle : "Title",
	labelContent : "Content",
	preview: "Preview"
});
