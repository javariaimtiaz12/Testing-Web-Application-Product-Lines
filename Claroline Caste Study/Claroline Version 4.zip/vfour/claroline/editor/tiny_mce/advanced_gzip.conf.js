tinyMCE_GZ.init({
	// plugins must be the same as in tinyMCE.init
	plugins : "template,media,paste,table,safari,claroimage,dailytube",
	themes : "advanced",
	languages : "en",
	disk_cache : true,
	debug : false
});