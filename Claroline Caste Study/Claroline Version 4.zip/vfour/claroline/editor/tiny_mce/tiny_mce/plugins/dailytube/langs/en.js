tinyMCE.addI18n('en.dailytube',{
	desc : 'Insert DailyMotion or YouTube video'
});
