tinyMCE.addI18n('en.texformula_dlg',{
	title : "LaTex Formula Editor",
	label : "Formula",
	preview: "Preview"
});
