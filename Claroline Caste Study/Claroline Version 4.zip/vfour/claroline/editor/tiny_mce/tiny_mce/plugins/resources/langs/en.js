tinyMCE.addI18n('en.resources',{
	desc : 'Resources linker'
});
