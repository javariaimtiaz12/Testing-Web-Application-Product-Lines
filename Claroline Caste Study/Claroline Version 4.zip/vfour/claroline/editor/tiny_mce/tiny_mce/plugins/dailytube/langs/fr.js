tinyMCE.addI18n('fr.dailytube',{
	desc : 'Ins�rer une vid�o DailyMotion ou YouTube'
});
