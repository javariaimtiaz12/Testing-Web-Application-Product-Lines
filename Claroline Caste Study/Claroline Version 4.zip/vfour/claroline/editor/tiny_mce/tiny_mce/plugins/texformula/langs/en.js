tinyMCE.addI18n('en.texformula',{
	desc : 'LaTeX equation  editor'
});
