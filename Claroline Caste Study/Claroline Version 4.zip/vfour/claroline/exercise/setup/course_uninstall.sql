DROP TABLE IF EXISTS `__CL_COURSE__qwz_exercise`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_question`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_rel_exercise_question`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_answer_truefalse`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_answer_multiple_choice`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_answer_fib`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_answer_matching`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_tracking`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_tracking_questions`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_tracking_answers`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_users_random_questions`;

DROP TABLE IF EXISTS `__CL_COURSE__qwz_questions_categories`