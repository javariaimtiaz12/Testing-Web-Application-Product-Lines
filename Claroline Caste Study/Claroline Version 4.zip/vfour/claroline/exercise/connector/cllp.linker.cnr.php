<?php
/*
 * this file is currently only here to say to new learning path module (CLLP) that
 * exercises can be added to a learning path
 */
