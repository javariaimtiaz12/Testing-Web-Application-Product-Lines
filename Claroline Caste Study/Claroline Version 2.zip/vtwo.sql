-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2021 at 08:59 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vtwo`
--

-- --------------------------------------------------------

--
-- Table structure for table `cl_category`
--

CREATE TABLE `cl_category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `code` varchar(12) NOT NULL DEFAULT '',
  `idParent` int(11) DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `canHaveCoursesChild` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_category`
--

INSERT INTO `cl_category` (`id`, `name`, `code`, `idParent`, `rank`, `visible`, `canHaveCoursesChild`) VALUES
(0, 'Root', 'ROOT', NULL, 0, 0, 0),
(2, 'Sciences', 'SC', 0, 1, 1, 1),
(3, 'Economics', 'ECO', 0, 2, 1, 1),
(4, 'Humanities', 'HUMA', 0, 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cl_class`
--

CREATE TABLE `cl_class` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `class_parent_id` int(11) DEFAULT NULL,
  `class_level` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='classe_id, name, classe_parent_id, classe_level';

-- --------------------------------------------------------

--
-- Table structure for table `cl_config_file`
--

CREATE TABLE `cl_config_file` (
  `config_code` varchar(30) NOT NULL DEFAULT '',
  `config_hash` varchar(40) NOT NULL DEFAULT ''
) ENGINE=MyISAM AVG_ROW_LENGTH=48 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_config_file`
--

INSERT INTO `cl_config_file` (`config_code`, `config_hash`) VALUES
('CLAUTH', '42d39a6ffe0ca97dc5a201e7bb8ce34a'),
('CLCAS', 'cf9eaf15360569476fe54f4143c59fc2'),
('CLCRS', 'e5438a6493a3e01563dcc8878c4727cf'),
('CLGRP', '8dc7830732ed7c6619eb802bc01192a7'),
('CLHOME', '8941dbd4347cebbd3e1b3e538a16ec9d'),
('CLICAL', '3b858030b45bfa15ad5ace4f9bf2ea2f'),
('CLKCACHE', 'b82baadc7d5f1bcd2619a6d572717b72'),
('CLMAIN', '4294f2b3c661664d2f073571e2b632d1'),
('CLMSG', 'e07ed631ee1a0ad93bbbdc69d3f59832'),
('CLPROFIL', 'b65fd4b6d900ff42b1eff0b33fde9196'),
('CLRSS', '19910878c0d8b3d1c11295dc8a138820'),
('CLSSO', '17ed796366238ec6cfc42f4fac6a63a3'),
('CLDSC', '79b73f892c501e9dd3b7f2ae75c02ad5'),
('CLANN', '5a8e0568a4bf96822338ba5e5b45de5d'),
('CLDOC', '6d94edc66cf5e81d6662493cc82798ee'),
('CLQWZ', '89cd3aa1bf479df544b998e4972cee2c'),
('CLLNP', '82ff3c43571abba23abdedad013bda5b'),
('CLWRK', 'ae39dee702a8e6d23aaf2d6d393b9fd8'),
('CLFRM', 'fa134056e7b5bd9fcb4bb9a81124acb8'),
('CLUSR', '8ce050e558198a1b2e5fedaeccf00559'),
('CLWIKI', 'bba77330eac26aa74cf3bd17e001326f'),
('CLCHAT', 'e161a647aa2d70da54af891c66e00c2e');

-- --------------------------------------------------------

--
-- Table structure for table `cl_cours`
--

CREATE TABLE `cl_cours` (
  `cours_id` int(11) NOT NULL,
  `code` varchar(40) DEFAULT NULL,
  `isSourceCourse` tinyint(4) NOT NULL DEFAULT '0',
  `sourceCourseId` int(11) DEFAULT NULL,
  `administrativeNumber` varchar(40) DEFAULT NULL,
  `directory` varchar(20) DEFAULT NULL,
  `dbName` varchar(40) DEFAULT NULL,
  `language` varchar(15) DEFAULT NULL,
  `intitule` varchar(250) DEFAULT NULL,
  `titulaires` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `extLinkName` varchar(30) DEFAULT NULL,
  `extLinkUrl` varchar(180) DEFAULT NULL,
  `visibility` enum('visible','invisible') NOT NULL DEFAULT 'visible',
  `access` enum('public','private','platform') NOT NULL DEFAULT 'public',
  `registration` enum('open','close','validation') NOT NULL DEFAULT 'open',
  `registrationKey` varchar(255) DEFAULT NULL,
  `diskQuota` int(10) UNSIGNED DEFAULT NULL,
  `versionDb` varchar(250) NOT NULL DEFAULT 'NEVER SET',
  `versionClaro` varchar(250) NOT NULL DEFAULT 'NEVER SET',
  `lastVisit` datetime DEFAULT NULL,
  `lastEdit` datetime DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  `defaultProfileId` int(11) NOT NULL,
  `status` enum('enable','pending','disable','trash','date') NOT NULL DEFAULT 'enable',
  `userLimit` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='data of courses';

--
-- Dumping data for table `cl_cours`
--

INSERT INTO `cl_cours` (`cours_id`, `code`, `isSourceCourse`, `sourceCourseId`, `administrativeNumber`, `directory`, `dbName`, `language`, `intitule`, `titulaires`, `email`, `extLinkName`, `extLinkUrl`, `visibility`, `access`, `registration`, `registrationKey`, `diskQuota`, `versionDb`, `versionClaro`, `lastVisit`, `lastEdit`, `creationDate`, `expirationDate`, `defaultProfileId`, `status`, `userLimit`) VALUES
(1, '0032_001', 0, NULL, '0032', '0032_001', 'c_0032_001', 'english', 'Software Engineering', 'Admin Super', 'admin@admin.com', '', '', 'visible', 'public', 'open', '', NULL, '1.11.10', '1.11.10', NULL, '2021-07-05 11:49:29', '2021-07-05 11:49:29', NULL, 3, 'enable', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cl_coursehomepage_portlet`
--

CREATE TABLE `cl_coursehomepage_portlet` (
  `label` varchar(10) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_coursehomepage_portlet`
--

INSERT INTO `cl_coursehomepage_portlet` (`label`, `name`) VALUES
('CLTI', 'Headlines'),
('CLCAL', 'Calendar'),
('CLANN', 'Announcements');

-- --------------------------------------------------------

--
-- Table structure for table `cl_course_tool`
--

CREATE TABLE `cl_course_tool` (
  `id` int(10) UNSIGNED NOT NULL,
  `claro_label` varchar(8) NOT NULL DEFAULT '',
  `script_url` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(255) DEFAULT NULL,
  `def_access` enum('ALL','COURSE_MEMBER','GROUP_MEMBER','GROUP_TUTOR','COURSE_ADMIN','PLATFORM_ADMIN') NOT NULL DEFAULT 'ALL',
  `def_rank` int(10) UNSIGNED DEFAULT NULL,
  `add_in_course` enum('MANUAL','AUTOMATIC') NOT NULL DEFAULT 'AUTOMATIC',
  `access_manager` enum('PLATFORM_ADMIN','COURSE_ADMIN') NOT NULL DEFAULT 'COURSE_ADMIN'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='based definiton of the claroline tool used in each course';

--
-- Dumping data for table `cl_course_tool`
--

INSERT INTO `cl_course_tool` (`id`, `claro_label`, `script_url`, `icon`, `def_access`, `def_rank`, `add_in_course`, `access_manager`) VALUES
(1, 'CLDSC', 'index.php', 'icon.png', 'ALL', 1, 'AUTOMATIC', 'COURSE_ADMIN'),
(2, 'CLCAL', 'agenda.php', 'icon.png', 'ALL', 2, 'AUTOMATIC', 'COURSE_ADMIN'),
(3, 'CLANN', 'announcements.php', 'icon.png', 'ALL', 3, 'AUTOMATIC', 'COURSE_ADMIN'),
(4, 'CLDOC', 'document.php', 'icon.png', 'ALL', 4, 'AUTOMATIC', 'COURSE_ADMIN'),
(5, 'CLQWZ', 'exercise.php', 'icon.png', 'ALL', 5, 'AUTOMATIC', 'COURSE_ADMIN'),
(6, 'CLLNP', 'learningPathList.php', 'icon.png', 'ALL', 6, 'AUTOMATIC', 'COURSE_ADMIN'),
(7, 'CLWRK', 'work.php', 'icon.png', 'ALL', 7, 'AUTOMATIC', 'COURSE_ADMIN'),
(8, 'CLFRM', 'index.php', 'icon.png', 'ALL', 8, 'AUTOMATIC', 'COURSE_ADMIN'),
(9, 'CLGRP', 'group.php', 'icon.png', 'ALL', 9, 'AUTOMATIC', 'COURSE_ADMIN'),
(10, 'CLUSR', 'user.php', 'icon.png', 'ALL', 10, 'AUTOMATIC', 'COURSE_ADMIN'),
(11, 'CLWIKI', 'wiki.php', 'icon.png', 'ALL', 11, 'AUTOMATIC', 'COURSE_ADMIN'),
(12, 'CLCHAT', 'index.php', 'icon.png', 'ALL', 12, 'AUTOMATIC', 'COURSE_ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `cl_desktop_portlet`
--

CREATE TABLE `cl_desktop_portlet` (
  `label` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rank` int(11) NOT NULL,
  `visibility` enum('visible','invisible') NOT NULL DEFAULT 'visible',
  `activated` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_desktop_portlet`
--

INSERT INTO `cl_desktop_portlet` (`label`, `name`, `rank`, `visibility`, `activated`) VALUES
('mycourselist', 'My course list', 1, 'visible', 1),
('mymessages', 'My last messages', 2, 'visible', 1),
('CLCAL_Portlet', 'My calendar', 3, 'visible', 1),
('CLANN_Portlet', 'Latest announcements', 4, 'visible', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cl_desktop_portlet_data`
--

CREATE TABLE `cl_desktop_portlet_data` (
  `id` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `idUser` int(11) NOT NULL,
  `data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_dock`
--

CREATE TABLE `cl_dock` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `module_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `rank` tinyint(3) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_event_resource`
--

CREATE TABLE `cl_event_resource` (
  `event_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `course_code` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_im_message`
--

CREATE TABLE `cl_im_message` (
  `message_id` int(10) UNSIGNED NOT NULL,
  `sender` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `send_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `course` varchar(40) DEFAULT NULL,
  `group` int(11) DEFAULT NULL,
  `tools` char(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_im_message`
--

INSERT INTO `cl_im_message` (`message_id`, `sender`, `subject`, `message`, `send_time`, `course`, `group`, `tools`) VALUES
(1, 1, 'Course created : Software Engineering', 'July 05, 2021 at 08:49 AM<br />\n<br />\nCourse creation on VTwo by the user Admin Super ( admin@admin.com )<br />\n<br />\nCourse code : 0032<br />\nCourse title : Software Engineering<br />\nLecturer(s) : Admin Super<br />\nEmail : admin@admin.com<br />\nCategory : Humanities<br />\nLanguage : english<br />\nUrl : http://localhost/vtwo/claroline/course/index.php?cid=0032_001', '2021-07-05 08:49:30', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cl_im_message_status`
--

CREATE TABLE `cl_im_message_status` (
  `user_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_im_message_status`
--

INSERT INTO `cl_im_message_status` (`user_id`, `message_id`, `is_read`, `is_deleted`) VALUES
(1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cl_im_recipient`
--

CREATE TABLE `cl_im_recipient` (
  `message_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sent_to` enum('toUser','toGroup','toCourse','toAll') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_im_recipient`
--

INSERT INTO `cl_im_recipient` (`message_id`, `user_id`, `sent_to`) VALUES
(1, 1, 'toUser');

-- --------------------------------------------------------

--
-- Table structure for table `cl_log`
--

CREATE TABLE `cl_log` (
  `id` int(11) NOT NULL,
  `course_code` varchar(40) DEFAULT NULL,
  `tool_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(60) NOT NULL DEFAULT '',
  `data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_module`
--

CREATE TABLE `cl_module` (
  `id` int(11) UNSIGNED NOT NULL,
  `label` varchar(8) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `activation` enum('activated','desactivated') NOT NULL DEFAULT 'desactivated',
  `type` varchar(10) NOT NULL DEFAULT 'applet',
  `script_url` char(255) NOT NULL DEFAULT 'entry.php'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_module`
--

INSERT INTO `cl_module` (`id`, `label`, `name`, `activation`, `type`, `script_url`) VALUES
(1, 'CLDSC', 'Course description', 'activated', 'tool', 'index.php'),
(2, 'CLCAL', 'Agenda', 'activated', 'tool', 'agenda.php'),
(3, 'CLANN', 'Announcements', 'activated', 'tool', 'announcements.php'),
(4, 'CLDOC', 'Documents and Links', 'activated', 'tool', 'document.php'),
(5, 'CLQWZ', 'Exercises', 'activated', 'tool', 'exercise.php'),
(6, 'CLLNP', 'Learning path', 'activated', 'tool', 'learningPathList.php'),
(7, 'CLWRK', 'Assignments', 'activated', 'tool', 'work.php'),
(8, 'CLFRM', 'Forums', 'activated', 'tool', 'index.php'),
(9, 'CLGRP', 'Groups', 'activated', 'tool', 'group.php'),
(10, 'CLUSR', 'Users', 'activated', 'tool', 'user.php'),
(11, 'CLWIKI', 'Wiki', 'activated', 'tool', 'wiki.php'),
(12, 'CLCHAT', 'Chat', 'activated', 'tool', 'index.php');

-- --------------------------------------------------------

--
-- Table structure for table `cl_module_contexts`
--

CREATE TABLE `cl_module_contexts` (
  `module_id` int(10) UNSIGNED NOT NULL,
  `context` varchar(60) NOT NULL DEFAULT 'course'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_module_contexts`
--

INSERT INTO `cl_module_contexts` (`module_id`, `context`) VALUES
(1, 'course'),
(2, 'course'),
(3, 'course'),
(4, 'course'),
(4, 'group'),
(5, 'course'),
(6, 'course'),
(7, 'course'),
(8, 'course'),
(8, 'group'),
(9, 'course'),
(10, 'course'),
(11, 'course'),
(11, 'group'),
(12, 'course'),
(12, 'group');

-- --------------------------------------------------------

--
-- Table structure for table `cl_module_info`
--

CREATE TABLE `cl_module_info` (
  `id` smallint(6) NOT NULL,
  `module_id` smallint(6) NOT NULL DEFAULT '0',
  `version` varchar(10) NOT NULL DEFAULT '',
  `author` varchar(50) DEFAULT NULL,
  `author_email` varchar(100) DEFAULT NULL,
  `author_website` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `license` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_module_info`
--

INSERT INTO `cl_module_info` (`id`, `module_id`, `version`, `author`, `author_email`, `author_website`, `description`, `website`, `license`) VALUES
(1, 1, '1.9', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n  ', 'http://wiki.claroline.net/index.php/CLDSC', 'GPL'),
(2, 2, '3.0', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n  ', 'http://wiki.claroline.net/index.php/CLCAL', 'GPL'),
(3, 3, '3.0', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n  ', 'http://wiki.claroline.net/index.php/CLANN', 'GPL'),
(4, 4, '4.0', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n     This tool is an original tool of claroline\n     It\'s able to store and manage local ressoures like file, url.\n     Can  manage upload, zip, images, url, subdirectory\n     Ca edit html files\n  ', 'http://wiki.claroline.net/index.php/CLDOC', 'GPL'),
(5, 5, '1.8', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n  ', 'http://wiki.claroline.net/index.php/CLQWZ', 'GPL'),
(6, 6, '1.0', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n  ', 'http://www.claroline.net/wiki/CLLNP/', 'GPL'),
(7, 7, '1.8', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n  ', '', 'GPL'),
(8, 8, '1.8', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n  ', 'http://wiki.claroline.net/index.php/CLFRM', 'GPL'),
(9, 9, '1.8', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n        This tool allows group-based activities and group management in Claroline\n    ', 'http://wiki.claroline.net/index.php/CLGRP', 'GPL'),
(10, 10, '4.0', 'Claro team', 'devteam@claroline.net', 'http://www.claroline.net/', '\n  ', 'http://wiki.claroline.net/index.php/CLUSR', 'GPL'),
(11, 11, '2.0', 'Frederic Minne', 'zefredz@claroline.net', 'http://wiki.claroline.net/index.php/CLWIKI', '\n     This is the original Wiki tool for the Claroline platform. It allows\n     online collaborative edition of web pages using a simplified Wiki\n     syntax based on Olivier Meunier\'s wiki2xhtml renderer from the\n     Dotclear blog project.\n  ', 'http://wiki.claroline.net/index.php/CLWIKI', 'GPL'),
(12, 12, '1.0', 'Sebastien Piraux', 'seb@claroline.net', 'http://www.claroline.net', '\n    \n  ', '', 'GPL');

-- --------------------------------------------------------

--
-- Table structure for table `cl_notify`
--

CREATE TABLE `cl_notify` (
  `id` int(11) NOT NULL,
  `course_code` varchar(40) NOT NULL DEFAULT '0',
  `tool_id` int(11) NOT NULL DEFAULT '0',
  `ressource_id` varchar(255) NOT NULL DEFAULT '0',
  `group_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_property_definition`
--

CREATE TABLE `cl_property_definition` (
  `propertyId` varchar(50) NOT NULL DEFAULT '',
  `contextScope` varchar(10) NOT NULL DEFAULT '',
  `label` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(10) NOT NULL DEFAULT '',
  `defaultValue` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `acceptedValue` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_rel_class_user`
--

CREATE TABLE `cl_rel_class_user` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `class_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_rel_course_category`
--

CREATE TABLE `cl_rel_course_category` (
  `courseId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `rootCourse` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_rel_course_category`
--

INSERT INTO `cl_rel_course_category` (`courseId`, `categoryId`, `rootCourse`) VALUES
(1, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cl_rel_course_class`
--

CREATE TABLE `cl_rel_course_class` (
  `courseId` varchar(40) NOT NULL,
  `classId` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_rel_course_portlet`
--

CREATE TABLE `cl_rel_course_portlet` (
  `id` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `visible` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_rel_course_user`
--

CREATE TABLE `cl_rel_course_user` (
  `code_cours` varchar(40) NOT NULL DEFAULT '0',
  `user_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `profile_id` int(11) NOT NULL,
  `role` varchar(60) DEFAULT NULL,
  `team` int(11) NOT NULL DEFAULT '0',
  `tutor` int(11) NOT NULL DEFAULT '0',
  `count_user_enrol` int(11) NOT NULL DEFAULT '0',
  `count_class_enrol` int(11) NOT NULL DEFAULT '0',
  `isPending` tinyint(4) NOT NULL DEFAULT '0',
  `isCourseManager` tinyint(4) NOT NULL DEFAULT '0',
  `enrollment_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_rel_course_user`
--

INSERT INTO `cl_rel_course_user` (`code_cours`, `user_id`, `profile_id`, `role`, `team`, `tutor`, `count_user_enrol`, `count_class_enrol`, `isPending`, `isCourseManager`, `enrollment_date`) VALUES
('0032_001', 1, 4, NULL, 0, 1, 1, 0, 0, 1, '2021-07-05 11:49:30');

-- --------------------------------------------------------

--
-- Table structure for table `cl_right_action`
--

CREATE TABLE `cl_right_action` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `tool_id` int(11) DEFAULT NULL,
  `rank` int(11) DEFAULT '0',
  `type` enum('COURSE','PLATFORM') NOT NULL DEFAULT 'COURSE'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_right_action`
--

INSERT INTO `cl_right_action` (`id`, `name`, `description`, `tool_id`, `rank`, `type`) VALUES
(1, 'read', '', 1, 0, 'COURSE'),
(2, 'edit', '', 1, 0, 'COURSE'),
(3, 'read', '', 2, 0, 'COURSE'),
(4, 'edit', '', 2, 0, 'COURSE'),
(5, 'read', '', 3, 0, 'COURSE'),
(6, 'edit', '', 3, 0, 'COURSE'),
(7, 'read', '', 4, 0, 'COURSE'),
(8, 'edit', '', 4, 0, 'COURSE'),
(9, 'read', '', 5, 0, 'COURSE'),
(10, 'edit', '', 5, 0, 'COURSE'),
(11, 'read', '', 6, 0, 'COURSE'),
(12, 'edit', '', 6, 0, 'COURSE'),
(13, 'read', '', 7, 0, 'COURSE'),
(14, 'edit', '', 7, 0, 'COURSE'),
(15, 'read', '', 8, 0, 'COURSE'),
(16, 'edit', '', 8, 0, 'COURSE'),
(17, 'read', '', 9, 0, 'COURSE'),
(18, 'edit', '', 9, 0, 'COURSE'),
(19, 'read', '', 10, 0, 'COURSE'),
(20, 'edit', '', 10, 0, 'COURSE'),
(21, 'read', '', 11, 0, 'COURSE'),
(22, 'edit', '', 11, 0, 'COURSE'),
(23, 'read', '', 12, 0, 'COURSE'),
(24, 'edit', '', 12, 0, 'COURSE');

-- --------------------------------------------------------

--
-- Table structure for table `cl_right_profile`
--

CREATE TABLE `cl_right_profile` (
  `profile_id` int(11) NOT NULL,
  `type` enum('COURSE','PLATFORM') NOT NULL DEFAULT 'COURSE',
  `name` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `courseManager` tinyint(4) DEFAULT '0',
  `mailingList` tinyint(4) DEFAULT '0',
  `userlistPublic` tinyint(4) DEFAULT '0',
  `groupTutor` tinyint(4) DEFAULT '0',
  `locked` tinyint(4) DEFAULT '0',
  `required` tinyint(4) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_right_profile`
--

INSERT INTO `cl_right_profile` (`profile_id`, `type`, `name`, `label`, `description`, `courseManager`, `mailingList`, `userlistPublic`, `groupTutor`, `locked`, `required`) VALUES
(1, 'COURSE', 'Anonymous', 'anonymous', 'Course visitor (the user has no account on the platform)', 0, 1, 1, 0, 0, 1),
(2, 'COURSE', 'Guest', 'guest', 'Course visitor (the user has an account on the platform, but is not enrolled in the course)', 0, 1, 1, 0, 0, 1),
(3, 'COURSE', 'User', 'user', 'Course member (the user is actually enrolled in the course)', 0, 1, 1, 0, 0, 1),
(4, 'COURSE', 'Manager', 'manager', 'Course Administrator', 1, 1, 1, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cl_right_rel_profile_action`
--

CREATE TABLE `cl_right_rel_profile_action` (
  `profile_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `courseId` varchar(40) NOT NULL DEFAULT '',
  `value` tinyint(4) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_right_rel_profile_action`
--

INSERT INTO `cl_right_rel_profile_action` (`profile_id`, `action_id`, `courseId`, `value`) VALUES
(1, 23, '', 1),
(2, 23, '', 1),
(3, 23, '', 1),
(4, 23, '', 1),
(1, 24, '', 0),
(2, 24, '', 0),
(3, 24, '', 0),
(4, 24, '', 1),
(1, 22, '', 0),
(1, 21, '', 1),
(2, 22, '', 0),
(2, 21, '', 1),
(3, 22, '', 0),
(3, 21, '', 1),
(4, 22, '', 1),
(1, 20, '', 0),
(1, 19, '', 1),
(1, 18, '', 0),
(2, 20, '', 0),
(2, 19, '', 1),
(3, 20, '', 0),
(3, 19, '', 1),
(4, 21, '', 1),
(1, 17, '', 1),
(1, 16, '', 0),
(1, 15, '', 1),
(2, 18, '', 0),
(2, 17, '', 1),
(3, 18, '', 0),
(3, 17, '', 1),
(3, 16, '', 0),
(4, 20, '', 1),
(4, 19, '', 1),
(4, 18, '', 1),
(4, 17, '', 1),
(1, 13, '', 1),
(1, 14, '', 0),
(2, 16, '', 0),
(2, 15, '', 1),
(2, 13, '', 1),
(3, 15, '', 1),
(3, 13, '', 1),
(3, 14, '', 0),
(4, 16, '', 1),
(4, 15, '', 1),
(4, 13, '', 1),
(4, 14, '', 1),
(1, 12, '', 0),
(1, 11, '', 1),
(2, 14, '', 0),
(2, 12, '', 0),
(2, 11, '', 1),
(3, 12, '', 0),
(3, 11, '', 1),
(4, 12, '', 1),
(4, 11, '', 1),
(1, 10, '', 0),
(1, 9, '', 1),
(2, 10, '', 0),
(2, 9, '', 1),
(3, 10, '', 0),
(3, 9, '', 1),
(4, 10, '', 1),
(4, 9, '', 1),
(1, 8, '', 0),
(1, 7, '', 1),
(2, 8, '', 0),
(2, 7, '', 1),
(3, 8, '', 0),
(3, 7, '', 1),
(4, 8, '', 1),
(4, 7, '', 1),
(1, 6, '', 0),
(1, 5, '', 1),
(2, 6, '', 0),
(2, 5, '', 1),
(3, 6, '', 0),
(3, 5, '', 1),
(4, 6, '', 1),
(4, 5, '', 1),
(1, 4, '', 0),
(1, 3, '', 1),
(2, 4, '', 0),
(2, 3, '', 1),
(3, 4, '', 0),
(3, 3, '', 1),
(4, 4, '', 1),
(4, 3, '', 1),
(1, 2, '', 0),
(1, 1, '', 1),
(2, 2, '', 0),
(2, 1, '', 1),
(3, 2, '', 0),
(3, 1, '', 1),
(4, 2, '', 1),
(4, 1, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cl_sso`
--

CREATE TABLE `cl_sso` (
  `id` int(11) NOT NULL,
  `cookie` varchar(255) NOT NULL DEFAULT '',
  `rec_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_tracking_event`
--

CREATE TABLE `cl_tracking_event` (
  `id` int(11) NOT NULL,
  `course_code` varchar(40) DEFAULT NULL,
  `tool_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(60) NOT NULL DEFAULT '',
  `data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_tracking_event`
--

INSERT INTO `cl_tracking_event` (`id`, `course_code`, `tool_id`, `user_id`, `date`, `type`, `data`) VALUES
(1, NULL, NULL, 1, '2021-07-05 08:49:00', 'user_login', 'a:1:{s:2:\"ip\";s:3:\"::1\";}');

-- --------------------------------------------------------

--
-- Table structure for table `cl_upgrade_status`
--

CREATE TABLE `cl_upgrade_status` (
  `id` int(11) NOT NULL,
  `cid` varchar(40) NOT NULL,
  `claro_label` varchar(8) DEFAULT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cl_user`
--

CREATE TABLE `cl_user` (
  `user_id` int(11) UNSIGNED NOT NULL,
  `nom` varchar(60) DEFAULT NULL,
  `prenom` varchar(60) DEFAULT NULL,
  `username` varchar(255) DEFAULT 'empty',
  `password` varchar(50) DEFAULT 'empty',
  `language` varchar(15) DEFAULT NULL,
  `authSource` varchar(50) DEFAULT 'claroline',
  `email` varchar(255) DEFAULT NULL,
  `officialCode` varchar(255) DEFAULT NULL,
  `officialEmail` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(30) DEFAULT NULL,
  `pictureUri` varchar(250) DEFAULT NULL,
  `creatorId` int(11) UNSIGNED DEFAULT NULL,
  `isPlatformAdmin` tinyint(4) DEFAULT '0',
  `isCourseCreator` tinyint(4) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cl_user`
--

INSERT INTO `cl_user` (`user_id`, `nom`, `prenom`, `username`, `password`, `language`, `authSource`, `email`, `officialCode`, `officialEmail`, `phoneNumber`, `pictureUri`, `creatorId`, `isPlatformAdmin`, `isCourseCreator`) VALUES
(1, 'Super', 'Admin', 'admin', 'admin', '', 'claroline', 'admin@admin.com', '', '', '', NULL, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cl_user_property`
--

CREATE TABLE `cl_user_property` (
  `userId` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `propertyId` varchar(255) NOT NULL DEFAULT '',
  `propertyValue` varchar(255) NOT NULL DEFAULT '',
  `scope` varchar(45) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_announcement`
--

CREATE TABLE `c_0032_001_announcement` (
  `id` mediumint(11) NOT NULL,
  `title` varchar(80) DEFAULT NULL,
  `contenu` text,
  `visibleFrom` date DEFAULT NULL,
  `visibleUntil` date DEFAULT NULL,
  `temps` date DEFAULT NULL,
  `ordre` mediumint(11) NOT NULL DEFAULT '0',
  `visibility` enum('SHOW','HIDE') NOT NULL DEFAULT 'SHOW'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='announcements table';

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_categories`
--

CREATE TABLE `c_0032_001_bb_categories` (
  `cat_id` int(10) NOT NULL,
  `cat_title` varchar(100) DEFAULT NULL,
  `cat_order` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_bb_categories`
--

INSERT INTO `c_0032_001_bb_categories` (`cat_id`, `cat_title`, `cat_order`) VALUES
(2, 'Main', 1),
(1, 'Group forums', 2);

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_forums`
--

CREATE TABLE `c_0032_001_bb_forums` (
  `forum_id` int(10) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `forum_name` varchar(150) DEFAULT NULL,
  `forum_desc` text,
  `forum_access` int(10) DEFAULT '1',
  `forum_moderator` int(10) DEFAULT NULL,
  `forum_topics` int(10) NOT NULL DEFAULT '0',
  `forum_posts` int(10) NOT NULL DEFAULT '0',
  `forum_last_post_id` int(10) NOT NULL DEFAULT '0',
  `cat_id` int(10) DEFAULT NULL,
  `forum_type` int(10) DEFAULT '0',
  `forum_order` int(10) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_bb_forums`
--

INSERT INTO `c_0032_001_bb_forums` (`forum_id`, `group_id`, `forum_name`, `forum_desc`, `forum_access`, `forum_moderator`, `forum_topics`, `forum_posts`, `forum_last_post_id`, `cat_id`, `forum_type`, `forum_order`) VALUES
(1, NULL, 'Test forum', 'Remove this through the forum admin tool', 2, 1, 1, 1, 1, 2, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_posts`
--

CREATE TABLE `c_0032_001_bb_posts` (
  `post_id` int(10) NOT NULL,
  `topic_id` int(10) NOT NULL DEFAULT '0',
  `forum_id` int(10) NOT NULL DEFAULT '0',
  `poster_id` int(10) NOT NULL DEFAULT '0',
  `post_time` varchar(20) DEFAULT NULL,
  `poster_ip` varchar(16) DEFAULT NULL,
  `nom` varchar(30) DEFAULT NULL,
  `prenom` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_bb_posts`
--

INSERT INTO `c_0032_001_bb_posts` (`post_id`, `topic_id`, `forum_id`, `poster_id`, `post_time`, `poster_ip`, `nom`, `prenom`) VALUES
(1, 1, 1, 1, '2021-07-05 11:49:30', '127.0.0.1', 'Super', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_posts_text`
--

CREATE TABLE `c_0032_001_bb_posts_text` (
  `post_id` int(10) NOT NULL DEFAULT '0',
  `post_text` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_bb_posts_text`
--

INSERT INTO `c_0032_001_bb_posts_text` (`post_id`, `post_text`) VALUES
(1, 'Message');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_priv_msgs`
--

CREATE TABLE `c_0032_001_bb_priv_msgs` (
  `msg_id` int(10) NOT NULL,
  `from_userid` int(10) NOT NULL DEFAULT '0',
  `to_userid` int(10) NOT NULL DEFAULT '0',
  `msg_time` varchar(20) DEFAULT NULL,
  `poster_ip` varchar(16) DEFAULT NULL,
  `msg_status` int(10) DEFAULT '0',
  `msg_text` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_rel_forum_userstonotify`
--

CREATE TABLE `c_0032_001_bb_rel_forum_userstonotify` (
  `notify_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT '0',
  `forum_id` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_rel_topic_userstonotify`
--

CREATE TABLE `c_0032_001_bb_rel_topic_userstonotify` (
  `notify_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT '0',
  `topic_id` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_topics`
--

CREATE TABLE `c_0032_001_bb_topics` (
  `topic_id` int(10) NOT NULL,
  `topic_title` varchar(100) DEFAULT NULL,
  `topic_poster` int(10) DEFAULT NULL,
  `topic_time` varchar(20) DEFAULT NULL,
  `topic_views` int(10) NOT NULL DEFAULT '0',
  `topic_replies` int(10) NOT NULL DEFAULT '0',
  `topic_last_post_id` int(10) NOT NULL DEFAULT '0',
  `forum_id` int(10) NOT NULL DEFAULT '0',
  `topic_status` int(10) NOT NULL DEFAULT '0',
  `topic_notify` int(2) DEFAULT '0',
  `nom` varchar(30) DEFAULT NULL,
  `prenom` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_bb_topics`
--

INSERT INTO `c_0032_001_bb_topics` (`topic_id`, `topic_title`, `topic_poster`, `topic_time`, `topic_views`, `topic_replies`, `topic_last_post_id`, `forum_id`, `topic_status`, `topic_notify`, `nom`, `prenom`) VALUES
(1, 'Example message', -1, '2021-07-05 11:49:30', 1, 0, 1, 1, 0, 1, 'Super', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_users`
--

CREATE TABLE `c_0032_001_bb_users` (
  `user_id` int(10) NOT NULL,
  `username` varchar(40) NOT NULL,
  `user_regdate` varchar(20) NOT NULL,
  `user_password` varchar(32) NOT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_icq` varchar(15) DEFAULT NULL,
  `user_website` varchar(100) DEFAULT NULL,
  `user_occ` varchar(100) DEFAULT NULL,
  `user_from` varchar(100) DEFAULT NULL,
  `user_intrest` varchar(150) DEFAULT NULL,
  `user_sig` varchar(255) DEFAULT NULL,
  `user_viewemail` tinyint(2) DEFAULT NULL,
  `user_theme` int(10) DEFAULT NULL,
  `user_aim` varchar(18) DEFAULT NULL,
  `user_yim` varchar(25) DEFAULT NULL,
  `user_msnm` varchar(25) DEFAULT NULL,
  `user_posts` int(10) DEFAULT '0',
  `user_attachsig` int(2) DEFAULT '0',
  `user_desmile` int(2) DEFAULT '0',
  `user_html` int(2) DEFAULT '0',
  `user_bbcode` int(2) DEFAULT '0',
  `user_rank` int(10) DEFAULT '0',
  `user_level` int(10) DEFAULT '1',
  `user_lang` varchar(255) DEFAULT NULL,
  `user_actkey` varchar(32) DEFAULT NULL,
  `user_newpasswd` varchar(32) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_bb_users`
--

INSERT INTO `c_0032_001_bb_users` (`user_id`, `username`, `user_regdate`, `user_password`, `user_email`, `user_icq`, `user_website`, `user_occ`, `user_from`, `user_intrest`, `user_sig`, `user_viewemail`, `user_theme`, `user_aim`, `user_yim`, `user_msnm`, `user_posts`, `user_attachsig`, `user_desmile`, `user_html`, `user_bbcode`, `user_rank`, `user_level`, `user_lang`, `user_actkey`, `user_newpasswd`) VALUES
(1, 'Super Admin', '2021-07-05 11:49:30', 'password', 'admin@admin.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, NULL, NULL),
(-1, 'Anonymous', '2021-07-05 11:49:30', 'password', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_bb_whosonline`
--

CREATE TABLE `c_0032_001_bb_whosonline` (
  `id` int(3) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `count` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `username` varchar(40) DEFAULT NULL,
  `forum` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_calendar_event`
--

CREATE TABLE `c_0032_001_calendar_event` (
  `id` int(11) NOT NULL,
  `titre` varchar(200) DEFAULT NULL,
  `contenu` text,
  `day` date NOT NULL DEFAULT '0000-00-00',
  `hour` time NOT NULL DEFAULT '00:00:00',
  `lasting` varchar(20) DEFAULT NULL,
  `speakers` varchar(150) DEFAULT NULL,
  `visibility` enum('SHOW','HIDE') NOT NULL DEFAULT 'SHOW',
  `location` varchar(150) DEFAULT NULL,
  `group_id` int(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_chat`
--

CREATE TABLE `c_0032_001_chat` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `group_id` int(11) DEFAULT NULL,
  `message` text,
  `post_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_chat_users`
--

CREATE TABLE `c_0032_001_chat_users` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `group_id` int(11) DEFAULT NULL,
  `last_action` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_course_description`
--

CREATE TABLE `c_0032_001_course_description` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL DEFAULT '-1',
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `lastEditDate` datetime NOT NULL,
  `visibility` enum('VISIBLE','INVISIBLE') NOT NULL DEFAULT 'VISIBLE'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_course_properties`
--

CREATE TABLE `c_0032_001_course_properties` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_course_properties`
--

INSERT INTO `c_0032_001_course_properties` (`id`, `name`, `value`, `category`) VALUES
(1, 'self_registration', '1', 'GROUP'),
(2, 'self_unregistration', '0', 'GROUP'),
(3, 'nbGroupPerUser', '1', 'GROUP'),
(4, 'private', '1', 'GROUP'),
(5, 'CLDOC', '1', 'GROUP'),
(6, 'CLFRM', '1', 'GROUP'),
(7, 'CLWIKI', '1', 'GROUP'),
(8, 'CLCHAT', '1', 'GROUP');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_document`
--

CREATE TABLE `c_0032_001_document` (
  `id` int(4) NOT NULL,
  `path` varchar(255) NOT NULL,
  `visibility` char(1) NOT NULL DEFAULT 'v',
  `comment` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_group_rel_team_user`
--

CREATE TABLE `c_0032_001_group_rel_team_user` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL DEFAULT '0',
  `team` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `role` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_group_team`
--

CREATE TABLE `c_0032_001_group_team` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text,
  `tutor` int(11) DEFAULT NULL,
  `maxStudent` int(11) DEFAULT '0',
  `secretDirectory` varchar(30) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_lnk_links`
--

CREATE TABLE `c_0032_001_lnk_links` (
  `id` int(11) NOT NULL,
  `src_id` int(11) NOT NULL DEFAULT '0',
  `dest_id` int(11) NOT NULL DEFAULT '0',
  `creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_lnk_resources`
--

CREATE TABLE `c_0032_001_lnk_resources` (
  `id` int(11) NOT NULL,
  `crl` text NOT NULL,
  `title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_lp_asset`
--

CREATE TABLE `c_0032_001_lp_asset` (
  `asset_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `comment` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='List of resources of module of learning paths';

--
-- Dumping data for table `c_0032_001_lp_asset`
--

INSERT INTO `c_0032_001_lp_asset` (`asset_id`, `module_id`, `path`, `comment`) VALUES
(1, 1, '/Example_document.pdf', ''),
(2, 2, '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_lp_learnpath`
--

CREATE TABLE `c_0032_001_lp_learnpath` (
  `learnPath_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `lock` enum('OPEN','CLOSE') NOT NULL DEFAULT 'OPEN',
  `visibility` enum('HIDE','SHOW') NOT NULL DEFAULT 'SHOW',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='List of learning Paths';

--
-- Dumping data for table `c_0032_001_lp_learnpath`
--

INSERT INTO `c_0032_001_lp_learnpath` (`learnPath_id`, `name`, `comment`, `lock`, `visibility`, `rank`) VALUES
(1, 'Sample learning path', 'This is a sample learning path, it uses the sample exercise and the sample document of the exercise tool and the document tool. Click on <b>Modify</b> to change this text.', 'OPEN', 'SHOW', 1);

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_lp_module`
--

CREATE TABLE `c_0032_001_lp_module` (
  `module_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `accessibility` enum('PRIVATE','PUBLIC') NOT NULL DEFAULT 'PRIVATE',
  `startAsset_id` int(11) NOT NULL DEFAULT '0',
  `contentType` enum('CLARODOC','DOCUMENT','EXERCISE','HANDMADE','SCORM','LABEL') NOT NULL,
  `launch_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='List of available modules used in learning paths';

--
-- Dumping data for table `c_0032_001_lp_module`
--

INSERT INTO `c_0032_001_lp_module` (`module_id`, `name`, `comment`, `accessibility`, `startAsset_id`, `contentType`, `launch_data`) VALUES
(1, 'example_document', 'You can use any document existing in the documents tool of this course.', 'PRIVATE', 1, 'DOCUMENT', ''),
(2, 'Sample exercise', 'You can use any exercise of the exercises tool of your course.', 'PRIVATE', 2, 'EXERCISE', '');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_lp_rel_learnpath_module`
--

CREATE TABLE `c_0032_001_lp_rel_learnpath_module` (
  `learnPath_module_id` int(11) NOT NULL,
  `learnPath_id` int(11) NOT NULL DEFAULT '0',
  `module_id` int(11) NOT NULL DEFAULT '0',
  `lock` enum('OPEN','CLOSE') NOT NULL DEFAULT 'OPEN',
  `visibility` enum('HIDE','SHOW') NOT NULL DEFAULT 'SHOW',
  `specificComment` text NOT NULL,
  `rank` int(11) NOT NULL DEFAULT '0',
  `parent` int(11) NOT NULL DEFAULT '0',
  `raw_to_pass` tinyint(4) NOT NULL DEFAULT '50'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='This table links module to the learning path using them';

--
-- Dumping data for table `c_0032_001_lp_rel_learnpath_module`
--

INSERT INTO `c_0032_001_lp_rel_learnpath_module` (`learnPath_module_id`, `learnPath_id`, `module_id`, `lock`, `visibility`, `specificComment`, `rank`, `parent`, `raw_to_pass`) VALUES
(1, 1, 1, 'OPEN', 'SHOW', '', 1, 0, 50),
(2, 1, 2, 'OPEN', 'SHOW', '', 2, 0, 50);

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_lp_user_module_progress`
--

CREATE TABLE `c_0032_001_lp_user_module_progress` (
  `user_module_progress_id` int(22) NOT NULL,
  `user_id` mediumint(9) NOT NULL DEFAULT '0',
  `learnPath_module_id` int(11) NOT NULL DEFAULT '0',
  `learnPath_id` int(11) NOT NULL DEFAULT '0',
  `lesson_location` varchar(255) NOT NULL DEFAULT '',
  `lesson_status` enum('NOT ATTEMPTED','PASSED','FAILED','COMPLETED','BROWSED','INCOMPLETE','UNKNOWN') NOT NULL DEFAULT 'NOT ATTEMPTED',
  `entry` enum('AB-INITIO','RESUME','') NOT NULL DEFAULT 'AB-INITIO',
  `raw` tinyint(4) NOT NULL DEFAULT '-1',
  `scoreMin` tinyint(4) NOT NULL DEFAULT '-1',
  `scoreMax` tinyint(4) NOT NULL DEFAULT '-1',
  `total_time` varchar(13) NOT NULL DEFAULT '0000:00:00.00',
  `session_time` varchar(13) NOT NULL DEFAULT '0000:00:00.00',
  `suspend_data` text NOT NULL,
  `credit` enum('CREDIT','NO-CREDIT') NOT NULL DEFAULT 'NO-CREDIT'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Record the last known status of the user in the course';

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_answer_fib`
--

CREATE TABLE `c_0032_001_qwz_answer_fib` (
  `id` int(11) NOT NULL,
  `questionId` int(11) NOT NULL,
  `answer` text NOT NULL,
  `gradeList` text NOT NULL,
  `wrongAnswerList` text NOT NULL,
  `type` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_answer_matching`
--

CREATE TABLE `c_0032_001_qwz_answer_matching` (
  `id` int(11) NOT NULL,
  `questionId` int(11) NOT NULL,
  `answer` text NOT NULL,
  `match` varchar(32) DEFAULT NULL,
  `grade` float NOT NULL DEFAULT '0',
  `code` varchar(32) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_answer_multiple_choice`
--

CREATE TABLE `c_0032_001_qwz_answer_multiple_choice` (
  `id` int(11) NOT NULL,
  `questionId` int(11) NOT NULL,
  `answer` text NOT NULL,
  `correct` tinyint(4) NOT NULL,
  `grade` float NOT NULL,
  `comment` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_qwz_answer_multiple_choice`
--

INSERT INTO `c_0032_001_qwz_answer_multiple_choice` (`id`, `questionId`, `answer`, `correct`, `grade`, `comment`) VALUES
(1, 1, 'Ridiculise one\'s interlocutor in order to have him concede he is wrong.', 0, -5, 'No. Socratic irony is not a matter of psychology, it concerns argument.'),
(2, 1, 'Admit one\'s own errors to invite one\'s interlocutor to do the same.', 0, -5, 'No. Socratic irony is not a seduction strategy nor a method based on the example.'),
(3, 1, 'Compel one\'s interlocutor, by a series of questions and sub-questions, to admit he doesn\'t know what he claims to know.', 1, 5, 'Indeed. Socratic irony is an interrogative method. The Greek \"eirotao\" means \"ask questions\"'),
(4, 1, 'Use the Principle of Non Contradiction to force one\'s interlocutor into a dead end.', 1, 5, 'This answer is not false. It is true that the revelation of the interlocutor\'s ignorance means showing the contradictory conclusions which lead from his premises.');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_answer_truefalse`
--

CREATE TABLE `c_0032_001_qwz_answer_truefalse` (
  `id` int(11) NOT NULL,
  `questionId` int(11) NOT NULL,
  `trueFeedback` text NOT NULL,
  `trueGrade` float NOT NULL,
  `falseFeedback` text NOT NULL,
  `falseGrade` float NOT NULL,
  `correctAnswer` enum('TRUE','FALSE') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_exercise`
--

CREATE TABLE `c_0032_001_qwz_exercise` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `visibility` enum('VISIBLE','INVISIBLE') NOT NULL DEFAULT 'INVISIBLE',
  `displayType` enum('SEQUENTIAL','ONEPAGE') NOT NULL DEFAULT 'ONEPAGE',
  `shuffle` smallint(6) NOT NULL DEFAULT '0',
  `useSameShuffle` enum('0','1') NOT NULL DEFAULT '0',
  `showAnswers` enum('ALWAYS','NEVER','LASTTRY') NOT NULL DEFAULT 'ALWAYS',
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL,
  `timeLimit` smallint(6) NOT NULL DEFAULT '0',
  `attempts` tinyint(4) NOT NULL DEFAULT '0',
  `anonymousAttempts` enum('ALLOWED','NOTALLOWED') NOT NULL DEFAULT 'NOTALLOWED',
  `quizEndMessage` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_qwz_exercise`
--

INSERT INTO `c_0032_001_qwz_exercise` (`id`, `title`, `description`, `visibility`, `displayType`, `shuffle`, `useSameShuffle`, `showAnswers`, `startDate`, `endDate`, `timeLimit`, `attempts`, `anonymousAttempts`, `quizEndMessage`) VALUES
(1, 'Sample exercise', 'History of Ancient Philosophy', 'INVISIBLE', 'ONEPAGE', 0, '0', 'ALWAYS', '2021-07-05 11:49:29', '2022-07-05 11:49:29', 0, 0, 'NOTALLOWED', '');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_question`
--

CREATE TABLE `c_0032_001_qwz_question` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `attachment` varchar(255) NOT NULL DEFAULT '',
  `type` enum('MCUA','MCMA','TF','FIB','MATCHING') NOT NULL DEFAULT 'MCUA',
  `grade` float NOT NULL DEFAULT '0',
  `id_category` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_qwz_question`
--

INSERT INTO `c_0032_001_qwz_question` (`id`, `title`, `description`, `attachment`, `type`, `grade`, `id_category`) VALUES
(1, 'Socratic irony is...', '(more than one answer can be true)', '', 'MCMA', 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_questions_categories`
--

CREATE TABLE `c_0032_001_qwz_questions_categories` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Record the categories of questions';

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_rel_exercise_question`
--

CREATE TABLE `c_0032_001_qwz_rel_exercise_question` (
  `exerciseId` int(11) NOT NULL,
  `questionId` int(11) NOT NULL,
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_qwz_rel_exercise_question`
--

INSERT INTO `c_0032_001_qwz_rel_exercise_question` (`exerciseId`, `questionId`, `rank`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_tracking`
--

CREATE TABLE `c_0032_001_qwz_tracking` (
  `id` int(11) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `exo_id` int(11) NOT NULL DEFAULT '0',
  `result` float NOT NULL DEFAULT '0',
  `time` mediumint(8) NOT NULL DEFAULT '0',
  `weighting` float NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Record informations about exercices';

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_tracking_answers`
--

CREATE TABLE `c_0032_001_qwz_tracking_answers` (
  `id` int(11) NOT NULL,
  `details_id` int(11) NOT NULL DEFAULT '0',
  `answer` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_tracking_questions`
--

CREATE TABLE `c_0032_001_qwz_tracking_questions` (
  `id` int(11) NOT NULL,
  `exercise_track_id` int(11) NOT NULL DEFAULT '0',
  `question_id` int(11) NOT NULL DEFAULT '0',
  `result` float NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Record answers of students in exercices';

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_qwz_users_random_questions`
--

CREATE TABLE `c_0032_001_qwz_users_random_questions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `exercise_id` int(11) NOT NULL,
  `questions` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_tool_intro`
--

CREATE TABLE `c_0032_001_tool_intro` (
  `id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `display_date` datetime DEFAULT NULL,
  `content` text,
  `rank` int(11) DEFAULT '1',
  `visibility` enum('SHOW','HIDE') NOT NULL DEFAULT 'SHOW'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_tool_list`
--

CREATE TABLE `c_0032_001_tool_list` (
  `id` int(11) NOT NULL,
  `tool_id` int(10) UNSIGNED DEFAULT NULL,
  `rank` int(10) UNSIGNED NOT NULL,
  `visibility` tinyint(4) DEFAULT '0',
  `script_url` varchar(255) DEFAULT NULL,
  `script_name` varchar(255) DEFAULT NULL,
  `addedTool` enum('YES','NO') DEFAULT 'YES',
  `activated` enum('true','false') NOT NULL DEFAULT 'true',
  `installed` enum('true','false') NOT NULL DEFAULT 'true'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c_0032_001_tool_list`
--

INSERT INTO `c_0032_001_tool_list` (`id`, `tool_id`, `rank`, `visibility`, `script_url`, `script_name`, `addedTool`, `activated`, `installed`) VALUES
(1, 1, 1, 1, NULL, NULL, 'YES', 'true', 'true'),
(2, 2, 2, 1, NULL, NULL, 'YES', 'true', 'true'),
(3, 3, 3, 1, NULL, NULL, 'YES', 'true', 'true'),
(4, 4, 4, 1, NULL, NULL, 'YES', 'true', 'true'),
(5, 5, 5, 1, NULL, NULL, 'YES', 'true', 'true'),
(6, 6, 6, 1, NULL, NULL, 'YES', 'true', 'true'),
(7, 7, 7, 1, NULL, NULL, 'YES', 'true', 'true'),
(8, 8, 8, 1, NULL, NULL, 'YES', 'true', 'true'),
(9, 9, 9, 1, NULL, NULL, 'YES', 'true', 'true'),
(10, 10, 10, 1, NULL, NULL, 'YES', 'true', 'true'),
(11, 11, 11, 1, NULL, NULL, 'YES', 'true', 'true'),
(12, 12, 12, 1, NULL, NULL, 'YES', 'true', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_tracking_event`
--

CREATE TABLE `c_0032_001_tracking_event` (
  `id` int(11) NOT NULL,
  `tool_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(60) NOT NULL DEFAULT '',
  `data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_userinfo_content`
--

CREATE TABLE `c_0032_001_userinfo_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `def_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ed_ip` varchar(39) DEFAULT NULL,
  `ed_date` datetime DEFAULT NULL,
  `content` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='content of users information';

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_userinfo_def`
--

CREATE TABLE `c_0032_001_userinfo_def` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(80) NOT NULL DEFAULT '',
  `comment` varchar(160) DEFAULT NULL,
  `nbLine` int(10) UNSIGNED NOT NULL DEFAULT '5',
  `rank` tinyint(3) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='categories definition for user information of a course';

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_wiki_acls`
--

CREATE TABLE `c_0032_001_wiki_acls` (
  `wiki_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `flag` varchar(255) NOT NULL DEFAULT '',
  `value` enum('false','true') NOT NULL DEFAULT 'false'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_wiki_pages`
--

CREATE TABLE `c_0032_001_wiki_pages` (
  `id` int(11) UNSIGNED NOT NULL,
  `wiki_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `owner_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `ctime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_version` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `last_mtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_wiki_pages_content`
--

CREATE TABLE `c_0032_001_wiki_pages_content` (
  `id` int(11) UNSIGNED NOT NULL,
  `pid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `editor_id` int(11) NOT NULL DEFAULT '0',
  `mtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_wiki_properties`
--

CREATE TABLE `c_0032_001_wiki_properties` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `group_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_wrk_assignment`
--

CREATE TABLE `c_0032_001_wrk_assignment` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `visibility` enum('VISIBLE','INVISIBLE') NOT NULL DEFAULT 'VISIBLE',
  `def_submission_visibility` enum('VISIBLE','INVISIBLE') NOT NULL DEFAULT 'VISIBLE',
  `assignment_type` enum('INDIVIDUAL','GROUP') NOT NULL DEFAULT 'INDIVIDUAL',
  `authorized_content` enum('TEXT','FILE','TEXTFILE') NOT NULL DEFAULT 'FILE',
  `allow_late_upload` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `prefill_text` text NOT NULL,
  `prefill_doc_path` varchar(200) NOT NULL DEFAULT '',
  `prefill_submit` enum('ENDDATE','AFTERPOST') NOT NULL DEFAULT 'ENDDATE'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c_0032_001_wrk_submission`
--

CREATE TABLE `c_0032_001_wrk_submission` (
  `id` int(11) NOT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL DEFAULT '',
  `visibility` enum('VISIBLE','INVISIBLE') DEFAULT 'VISIBLE',
  `creation_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_edit_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `authors` varchar(200) NOT NULL DEFAULT '',
  `submitted_text` text NOT NULL,
  `submitted_doc_path` varchar(200) NOT NULL DEFAULT '',
  `private_feedback` text,
  `original_id` int(11) DEFAULT NULL,
  `score` smallint(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cl_category`
--
ALTER TABLE `cl_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `cl_class`
--
ALTER TABLE `cl_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cl_config_file`
--
ALTER TABLE `cl_config_file`
  ADD PRIMARY KEY (`config_code`);

--
-- Indexes for table `cl_cours`
--
ALTER TABLE `cl_cours`
  ADD PRIMARY KEY (`cours_id`),
  ADD KEY `administrativeNumber` (`administrativeNumber`);

--
-- Indexes for table `cl_coursehomepage_portlet`
--
ALTER TABLE `cl_coursehomepage_portlet`
  ADD PRIMARY KEY (`label`);

--
-- Indexes for table `cl_course_tool`
--
ALTER TABLE `cl_course_tool`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `claro_label` (`claro_label`);

--
-- Indexes for table `cl_desktop_portlet`
--
ALTER TABLE `cl_desktop_portlet`
  ADD PRIMARY KEY (`label`);

--
-- Indexes for table `cl_desktop_portlet_data`
--
ALTER TABLE `cl_desktop_portlet_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cl_dock`
--
ALTER TABLE `cl_dock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cl_event_resource`
--
ALTER TABLE `cl_event_resource`
  ADD PRIMARY KEY (`event_id`,`resource_id`,`tool_id`,`course_code`),
  ADD UNIQUE KEY `event_id` (`event_id`,`course_code`);

--
-- Indexes for table `cl_im_message`
--
ALTER TABLE `cl_im_message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `cl_im_message_status`
--
ALTER TABLE `cl_im_message_status`
  ADD PRIMARY KEY (`user_id`,`message_id`);

--
-- Indexes for table `cl_im_recipient`
--
ALTER TABLE `cl_im_recipient`
  ADD PRIMARY KEY (`message_id`,`user_id`);

--
-- Indexes for table `cl_log`
--
ALTER TABLE `cl_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_code`),
  ADD KEY `user_log` (`user_id`);

--
-- Indexes for table `cl_module`
--
ALTER TABLE `cl_module`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cl_module_contexts`
--
ALTER TABLE `cl_module_contexts`
  ADD PRIMARY KEY (`module_id`,`context`);

--
-- Indexes for table `cl_module_info`
--
ALTER TABLE `cl_module_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cl_notify`
--
ALTER TABLE `cl_notify`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_code`);

--
-- Indexes for table `cl_property_definition`
--
ALTER TABLE `cl_property_definition`
  ADD PRIMARY KEY (`contextScope`,`propertyId`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `cl_rel_class_user`
--
ALTER TABLE `cl_rel_class_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `cl_rel_course_category`
--
ALTER TABLE `cl_rel_course_category`
  ADD PRIMARY KEY (`courseId`,`categoryId`);

--
-- Indexes for table `cl_rel_course_class`
--
ALTER TABLE `cl_rel_course_class`
  ADD PRIMARY KEY (`courseId`,`classId`);

--
-- Indexes for table `cl_rel_course_portlet`
--
ALTER TABLE `cl_rel_course_portlet`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `courseId` (`courseId`,`label`);

--
-- Indexes for table `cl_rel_course_user`
--
ALTER TABLE `cl_rel_course_user`
  ADD PRIMARY KEY (`code_cours`,`user_id`),
  ADD KEY `isCourseManager` (`isCourseManager`);

--
-- Indexes for table `cl_right_action`
--
ALTER TABLE `cl_right_action`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tool_id` (`tool_id`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `cl_right_profile`
--
ALTER TABLE `cl_right_profile`
  ADD PRIMARY KEY (`profile_id`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `cl_right_rel_profile_action`
--
ALTER TABLE `cl_right_rel_profile_action`
  ADD PRIMARY KEY (`profile_id`,`action_id`,`courseId`);

--
-- Indexes for table `cl_sso`
--
ALTER TABLE `cl_sso`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cl_tracking_event`
--
ALTER TABLE `cl_tracking_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_code`),
  ADD KEY `user_tracking` (`user_id`);

--
-- Indexes for table `cl_upgrade_status`
--
ALTER TABLE `cl_upgrade_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cl_user`
--
ALTER TABLE `cl_user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `loginpass` (`username`,`password`);

--
-- Indexes for table `cl_user_property`
--
ALTER TABLE `cl_user_property`
  ADD PRIMARY KEY (`scope`,`propertyId`,`userId`);

--
-- Indexes for table `c_0032_001_announcement`
--
ALTER TABLE `c_0032_001_announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_bb_categories`
--
ALTER TABLE `c_0032_001_bb_categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `c_0032_001_bb_forums`
--
ALTER TABLE `c_0032_001_bb_forums`
  ADD PRIMARY KEY (`forum_id`),
  ADD KEY `forum_last_post_id` (`forum_last_post_id`);

--
-- Indexes for table `c_0032_001_bb_posts`
--
ALTER TABLE `c_0032_001_bb_posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `forum_id` (`forum_id`),
  ADD KEY `topic_id` (`topic_id`),
  ADD KEY `poster_id` (`poster_id`);

--
-- Indexes for table `c_0032_001_bb_posts_text`
--
ALTER TABLE `c_0032_001_bb_posts_text`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `c_0032_001_bb_priv_msgs`
--
ALTER TABLE `c_0032_001_bb_priv_msgs`
  ADD PRIMARY KEY (`msg_id`),
  ADD KEY `to_userid` (`to_userid`);

--
-- Indexes for table `c_0032_001_bb_rel_forum_userstonotify`
--
ALTER TABLE `c_0032_001_bb_rel_forum_userstonotify`
  ADD PRIMARY KEY (`notify_id`),
  ADD KEY `SECONDARY` (`user_id`,`forum_id`);

--
-- Indexes for table `c_0032_001_bb_rel_topic_userstonotify`
--
ALTER TABLE `c_0032_001_bb_rel_topic_userstonotify`
  ADD PRIMARY KEY (`notify_id`),
  ADD KEY `SECONDARY` (`user_id`,`topic_id`);

--
-- Indexes for table `c_0032_001_bb_topics`
--
ALTER TABLE `c_0032_001_bb_topics`
  ADD PRIMARY KEY (`topic_id`),
  ADD KEY `forum_id` (`forum_id`),
  ADD KEY `topic_last_post_id` (`topic_last_post_id`);

--
-- Indexes for table `c_0032_001_bb_users`
--
ALTER TABLE `c_0032_001_bb_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `c_0032_001_bb_whosonline`
--
ALTER TABLE `c_0032_001_bb_whosonline`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_calendar_event`
--
ALTER TABLE `c_0032_001_calendar_event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_chat`
--
ALTER TABLE `c_0032_001_chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_chat_users`
--
ALTER TABLE `c_0032_001_chat_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_course_description`
--
ALTER TABLE `c_0032_001_course_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_course_properties`
--
ALTER TABLE `c_0032_001_course_properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_document`
--
ALTER TABLE `c_0032_001_document`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_group_rel_team_user`
--
ALTER TABLE `c_0032_001_group_rel_team_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_group_team`
--
ALTER TABLE `c_0032_001_group_team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_lnk_links`
--
ALTER TABLE `c_0032_001_lnk_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_lnk_resources`
--
ALTER TABLE `c_0032_001_lnk_resources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_lp_asset`
--
ALTER TABLE `c_0032_001_lp_asset`
  ADD PRIMARY KEY (`asset_id`);

--
-- Indexes for table `c_0032_001_lp_learnpath`
--
ALTER TABLE `c_0032_001_lp_learnpath`
  ADD PRIMARY KEY (`learnPath_id`),
  ADD UNIQUE KEY `rank` (`rank`);

--
-- Indexes for table `c_0032_001_lp_module`
--
ALTER TABLE `c_0032_001_lp_module`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `c_0032_001_lp_rel_learnpath_module`
--
ALTER TABLE `c_0032_001_lp_rel_learnpath_module`
  ADD PRIMARY KEY (`learnPath_module_id`);

--
-- Indexes for table `c_0032_001_lp_user_module_progress`
--
ALTER TABLE `c_0032_001_lp_user_module_progress`
  ADD PRIMARY KEY (`user_module_progress_id`);

--
-- Indexes for table `c_0032_001_qwz_answer_fib`
--
ALTER TABLE `c_0032_001_qwz_answer_fib`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_qwz_answer_matching`
--
ALTER TABLE `c_0032_001_qwz_answer_matching`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_qwz_answer_multiple_choice`
--
ALTER TABLE `c_0032_001_qwz_answer_multiple_choice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_qwz_answer_truefalse`
--
ALTER TABLE `c_0032_001_qwz_answer_truefalse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_qwz_exercise`
--
ALTER TABLE `c_0032_001_qwz_exercise`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_qwz_question`
--
ALTER TABLE `c_0032_001_qwz_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_qwz_questions_categories`
--
ALTER TABLE `c_0032_001_qwz_questions_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_qwz_tracking`
--
ALTER TABLE `c_0032_001_qwz_tracking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `exo_id` (`exo_id`);

--
-- Indexes for table `c_0032_001_qwz_tracking_answers`
--
ALTER TABLE `c_0032_001_qwz_tracking_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `details_id` (`details_id`);

--
-- Indexes for table `c_0032_001_qwz_tracking_questions`
--
ALTER TABLE `c_0032_001_qwz_tracking_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `exercise_track_id` (`exercise_track_id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `c_0032_001_qwz_users_random_questions`
--
ALTER TABLE `c_0032_001_qwz_users_random_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_exo` (`user_id`,`exercise_id`);

--
-- Indexes for table `c_0032_001_tool_intro`
--
ALTER TABLE `c_0032_001_tool_intro`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_tool_list`
--
ALTER TABLE `c_0032_001_tool_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_tracking_event`
--
ALTER TABLE `c_0032_001_tracking_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tool` (`tool_id`),
  ADD KEY `user` (`user_id`);

--
-- Indexes for table `c_0032_001_userinfo_content`
--
ALTER TABLE `c_0032_001_userinfo_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `c_0032_001_userinfo_def`
--
ALTER TABLE `c_0032_001_userinfo_def`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_wiki_pages`
--
ALTER TABLE `c_0032_001_wiki_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_wiki_pages_content`
--
ALTER TABLE `c_0032_001_wiki_pages_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_wiki_properties`
--
ALTER TABLE `c_0032_001_wiki_properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_wrk_assignment`
--
ALTER TABLE `c_0032_001_wrk_assignment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_0032_001_wrk_submission`
--
ALTER TABLE `c_0032_001_wrk_submission`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`user_id`),
  ADD KEY `original` (`original_id`),
  ADD KEY `visible` (`visibility`),
  ADD KEY `parent` (`parent_id`),
  ADD KEY `group` (`group_id`),
  ADD KEY `last_edit` (`last_edit_date`),
  ADD KEY `assigid` (`assignment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cl_category`
--
ALTER TABLE `cl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cl_class`
--
ALTER TABLE `cl_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_cours`
--
ALTER TABLE `cl_cours`
  MODIFY `cours_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cl_course_tool`
--
ALTER TABLE `cl_course_tool`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cl_desktop_portlet_data`
--
ALTER TABLE `cl_desktop_portlet_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_dock`
--
ALTER TABLE `cl_dock`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_im_message`
--
ALTER TABLE `cl_im_message`
  MODIFY `message_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cl_log`
--
ALTER TABLE `cl_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_module`
--
ALTER TABLE `cl_module`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cl_module_info`
--
ALTER TABLE `cl_module_info`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cl_notify`
--
ALTER TABLE `cl_notify`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_rel_class_user`
--
ALTER TABLE `cl_rel_class_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_rel_course_portlet`
--
ALTER TABLE `cl_rel_course_portlet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_right_action`
--
ALTER TABLE `cl_right_action`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `cl_right_profile`
--
ALTER TABLE `cl_right_profile`
  MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cl_sso`
--
ALTER TABLE `cl_sso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_tracking_event`
--
ALTER TABLE `cl_tracking_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cl_upgrade_status`
--
ALTER TABLE `cl_upgrade_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cl_user`
--
ALTER TABLE `cl_user`
  MODIFY `user_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_0032_001_announcement`
--
ALTER TABLE `c_0032_001_announcement`
  MODIFY `id` mediumint(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_categories`
--
ALTER TABLE `c_0032_001_bb_categories`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_forums`
--
ALTER TABLE `c_0032_001_bb_forums`
  MODIFY `forum_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_posts`
--
ALTER TABLE `c_0032_001_bb_posts`
  MODIFY `post_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_priv_msgs`
--
ALTER TABLE `c_0032_001_bb_priv_msgs`
  MODIFY `msg_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_rel_forum_userstonotify`
--
ALTER TABLE `c_0032_001_bb_rel_forum_userstonotify`
  MODIFY `notify_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_rel_topic_userstonotify`
--
ALTER TABLE `c_0032_001_bb_rel_topic_userstonotify`
  MODIFY `notify_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_topics`
--
ALTER TABLE `c_0032_001_bb_topics`
  MODIFY `topic_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_users`
--
ALTER TABLE `c_0032_001_bb_users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_0032_001_bb_whosonline`
--
ALTER TABLE `c_0032_001_bb_whosonline`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_calendar_event`
--
ALTER TABLE `c_0032_001_calendar_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_chat`
--
ALTER TABLE `c_0032_001_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_chat_users`
--
ALTER TABLE `c_0032_001_chat_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_course_description`
--
ALTER TABLE `c_0032_001_course_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_course_properties`
--
ALTER TABLE `c_0032_001_course_properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `c_0032_001_document`
--
ALTER TABLE `c_0032_001_document`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_group_rel_team_user`
--
ALTER TABLE `c_0032_001_group_rel_team_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_group_team`
--
ALTER TABLE `c_0032_001_group_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_lnk_links`
--
ALTER TABLE `c_0032_001_lnk_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_lnk_resources`
--
ALTER TABLE `c_0032_001_lnk_resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_lp_asset`
--
ALTER TABLE `c_0032_001_lp_asset`
  MODIFY `asset_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `c_0032_001_lp_learnpath`
--
ALTER TABLE `c_0032_001_lp_learnpath`
  MODIFY `learnPath_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_0032_001_lp_module`
--
ALTER TABLE `c_0032_001_lp_module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `c_0032_001_lp_rel_learnpath_module`
--
ALTER TABLE `c_0032_001_lp_rel_learnpath_module`
  MODIFY `learnPath_module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `c_0032_001_lp_user_module_progress`
--
ALTER TABLE `c_0032_001_lp_user_module_progress`
  MODIFY `user_module_progress_id` int(22) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_answer_fib`
--
ALTER TABLE `c_0032_001_qwz_answer_fib`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_answer_matching`
--
ALTER TABLE `c_0032_001_qwz_answer_matching`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_answer_multiple_choice`
--
ALTER TABLE `c_0032_001_qwz_answer_multiple_choice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_answer_truefalse`
--
ALTER TABLE `c_0032_001_qwz_answer_truefalse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_exercise`
--
ALTER TABLE `c_0032_001_qwz_exercise`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_question`
--
ALTER TABLE `c_0032_001_qwz_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_questions_categories`
--
ALTER TABLE `c_0032_001_qwz_questions_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_tracking`
--
ALTER TABLE `c_0032_001_qwz_tracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_tracking_answers`
--
ALTER TABLE `c_0032_001_qwz_tracking_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_tracking_questions`
--
ALTER TABLE `c_0032_001_qwz_tracking_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_qwz_users_random_questions`
--
ALTER TABLE `c_0032_001_qwz_users_random_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_tool_intro`
--
ALTER TABLE `c_0032_001_tool_intro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_tool_list`
--
ALTER TABLE `c_0032_001_tool_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `c_0032_001_tracking_event`
--
ALTER TABLE `c_0032_001_tracking_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_userinfo_content`
--
ALTER TABLE `c_0032_001_userinfo_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_userinfo_def`
--
ALTER TABLE `c_0032_001_userinfo_def`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_wiki_pages`
--
ALTER TABLE `c_0032_001_wiki_pages`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_wiki_pages_content`
--
ALTER TABLE `c_0032_001_wiki_pages_content`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_wiki_properties`
--
ALTER TABLE `c_0032_001_wiki_properties`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_wrk_assignment`
--
ALTER TABLE `c_0032_001_wrk_assignment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_0032_001_wrk_submission`
--
ALTER TABLE `c_0032_001_wrk_submission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
