<?php // $Id: index.php 13708 2011-10-19 10:46:34Z abourguignon $

/**
 * CLAROLINE
 *
 * @copyright   (c) 2001-2011, Universite catholique de Louvain (UCL)
 */

header('Location:./document.php');
exit();
