tinyMCE.addI18n('en.spoiler_dlg',{
	title : "Spoiler Editor",
	labelTitle : "Title",
	labelContent : "Content",
	preview: "Preview"
});
